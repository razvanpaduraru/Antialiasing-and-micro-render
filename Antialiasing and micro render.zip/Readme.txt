Nume : Paduraru Razvan-Stefan
Grupa : 331CA
Tema 1 APD

	Partea I : 
		Pentru aceasta parte am completat functiile din schelet. Pentru
		aceasta am avut nevoie sa fac o structura rgb, ce mentine deta-
		liile legate de culorile unui pixel(r, g, b). Pentru o poza
		alb-negru, doar campul r va avea o valoare, iar g = b = 0. In
		cazul unei poze color, toate campurile vor avea valoare. Structura
		image va contine tip-ul de imagine, latimea, inaltimea si maximul,
		dar si o matrice de rgb-uri. Structura struct_paral este folosita
		pentru paralelizare. Ea contine imaginea de in, cea de out si
		id-ul thread-ului pe care ne aflam.

		In cadrul functiei readInput am citit inputul si am populat struc-
		tura image, alocand desigur si matricea de rgb-uri. Pentru cazul
		in care trebuie sa citesc o poza alb-negru am citit matricea in-
		tr-un array, iar apoi am turnat in matrice, pentru a putea pune
		campurile g si b pe 0. Pentru cazul unei poze colore, a trebuit
		doar sa citesc cate 3 octeti pe linie, pe fiecare nivel al inalti-
		mii.

		In cadrul functiei writeData, a trebuit sa scriu informatia in
		fisier si la fel ca in functia readInput am afisat pe cazuri.
		(poza colora sau alb-negru).

		Pentru functia resize, am creat un threadFunction pentru a parale-
		liza desenarea pozei. In functia am creat vectorul tid si vectorul
		thread_id. Am alocat matricea de output cu dimensiunile impartite
		la resize_factor, iar apoi am setat pentru fiecare element al
		vectorului thread_id campurile. Apoi am apelat pe fiecare thread
		pthread_creat iar apoi join.

		Functia threadFunction face urmatoarele:
			a. calculeaza daca inaltimea si latimea se impart exact la
			resize factor, iar daca nu se va lua cel mai mare multiplu
			de resizefactor, mai mic decat acestea. Dupa aceea, se cal-
			culeaza start si end in functie de numarul thread-ului(am
			folosit metoda de impartire egala, iar ce ramane surplus,
			ofer ultimului thread).
			b. calcularea celor cerute in tema, pe cazuri(in cazul
			pozelor alb-negru cu resize_factor par, vom face suma doar
			pe r-uri al fiecarei submatrice de dimensiune resize_factor;
			pentru cazul in care resize_factor este 3, trebuie realizata
			inmultirea cu Kernel-ul Gaussian.) Inmultirea cu Kernel-ul
			Gaussian am optimizat-o facand un produs de convolutie, in-
			trucat acesta este constant. Dupa aceasta am impartit la 16
			si am adaugat in matricea out rezultatul.
			c. pentru cazul in care avem o poza colora, va trebui sa
			facem aceleasi operatii, doar ca pentru fiecare membru:r,g,b.

	Partea a II-a:
		De data aceasta am facut o structura image in care am retinut doar
		matricea de pixeli, care sunt unsigned char-uri. Pentru functia de
		initializare am alocat matricea si am colorat toata matricea in
		alb. In functia write data am scris matricea de pixeli. Functia
		render este asemanatoare functiei resize de la partea 1. Functia
		threadFunction va vedea ce puncte apartin dreptei si le va colora
		in negru.

TEST DE SCALABILITATE:

PARTEA 1:

	PENTRU ALB_NEGRU                                                                                                      
		Resize_factor = 2 :                                                                                                  
		
			Testez pentru 1 thread-uri
			0.006575

			Testez pentru 2 thread-uri
			0.003755

			Testez pentru 4 thread-uri
			0.001963

			Testez pentru 8 thread-uri
			0.001433

		Resize_factor = 3 :

			Testez pentru 1 thread-uri
			0.003063

			Testez pentru 2 thread-uri
			0.001672
			                                                                                                             
			Testez pentru 4 thread-uri
			0.001001
			                                                                                                          
			Testez pentru 8 thread-uri
			0.000874

		Resize_factor = 8

			Testez pentru 1  thread-uri
			0.002725

			Testez pentru 2  thread-uri
			0.001418

			Testez pentru 4  thread-uri
			0.000810

			Testez pentru 8  thread-uri
			0.000558

	PENTRU COLOR

		Resize_factor = 2

			Testez pentru 1 thread-uri
			0.009937

			Testez pentru 2 thread-uri
			0.005132

			Testez pentru 4 thread-uri
			0.002756

			Testez pentru 8 thread-uri
			0.001601

		Resize_factor = 3

			Testez pentru 1 thread-uri
			0.004990

			Testez pentru 2 thread-uri
			0.002632

			Testez pentru 4 thread-uri
			0.001460

			Testez pentru 8 thread-uri
			0.001053

		Resize_factor = 8

			Testez pentru 1 thread-uri
			0.004768

			Testez pentru 2 thread-uri
			0.002553
			                                                                                                   
			Testez pentru 4 thread-uri
			0.001382

			Testez pentru 8 thread-uri
			0.000909

Partea 2

	Pentru 1000 :

			Testez pentru 1 thread-uri
			0.038480

			Testez pentru 2 thread-uri
			0.020161

			Testez pentru 4 thread-uri
			0.008585

			Testez pentru 8 thread-uri
			0.004706

	Pentru 8000 :

			Testez pentru 1 thread-uri
			1.429418

			Testez pentru 2 thread-uri
			0.694283

			Testez pentru 4 thread-uri
			0.351694

			Testez pentru 8 thread-uri
			0.174566

	Se observa scalabilitatea, intrucat timpii sunt in scadere pentru un numar mai
	mare de thread-uri.