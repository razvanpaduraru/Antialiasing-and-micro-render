#include "homework.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

int num_threads;
int resize_factor;

void readInput(const char * fileName, image *img) {
	FILE* file = fopen(fileName, "rb");
	char c;

	fscanf(file, "%c %d %d %d %d ", &c, &img->tip, &img->latime, &img->inaltime, &img->maxim);

	img->imagine = malloc(img->inaltime * sizeof(rgb *));

	for (int i = 0; i < img->inaltime; ++i) {
		img->imagine[i] = malloc(img->latime * sizeof(rgb));
	}

	if (img->tip == 5) {
		unsigned char *citire;
		citire = malloc(sizeof(unsigned char) * (img->inaltime * img->latime));
		fread(citire, 1, (img->inaltime * img->latime), file);
		int k = 0;
		for (int i = 0; i < img->inaltime; ++i) {
			for (int j = 0; j < img->latime; ++j) {
				img->imagine[i][j].r = citire[k];
				img->imagine[i][j].g = 0;
				img->imagine[i][j].b = 0;
				k++;
			}
		}
	} else {
		for (int i = 0; i < img->inaltime; ++i) {
			fread(img->imagine[i], 1, img->latime * 3, file);
		}
	}
}

void writeData(const char * fileName, image *img) {
	FILE* file = fopen(fileName, "w");

	if (img->tip == 5) {
		fprintf(file, "P5\n");
	} else {
		fprintf(file, "P6\n");
	}

	fprintf(file, "%d %d\n", img->latime, img->inaltime);
	fprintf(file, "%d\n", img->maxim);

	if (img->tip == 5) {
		unsigned char* afisare;
		afisare = malloc(sizeof(unsigned char) * (img->inaltime * img->latime));
		int k = 0;
		for (int i = 0; i < img->inaltime; ++i) {
			for (int j = 0; j < img->latime; ++j) {
				afisare[k] = img->imagine[i][j].r;
				k++;
			}
		}
		fwrite(afisare, 1, sizeof(unsigned char) * (img->inaltime * img->latime), file);
	} else {
		for (int i = 0; i < img->inaltime; ++i) {
			fwrite(img->imagine[i], 1, sizeof(unsigned char) * (3 * img->latime), file);
		}
	}

}

void* threadFunction(void *var) {
	struct_paral vari = *(struct_paral*) var;

	int inaltime = vari.in->inaltime, latime = vari.in->latime;

	if (vari.in->latime / resize_factor * resize_factor != vari.in->latime) {
		latime = vari.in->latime / resize_factor * resize_factor;
	}

	if (vari.in->inaltime / resize_factor * resize_factor != vari.in->inaltime) {
		inaltime = vari.in->inaltime / resize_factor * resize_factor;
	}

	int start = vari.id * (inaltime / num_threads);
	int end = start + (inaltime / num_threads);

	if(vari.id == num_threads - 1) {
		end = inaltime;
	}

	if (resize_factor % 2 == 0 && vari.in->tip == 5) {

		for(int i = start; i < end; i += 1) {
			if (i % resize_factor == 0) {
				for (int j = 0; j < latime; j += resize_factor) {
					int s = 0;
					int aritm;
					for (int k1 = i; k1 < i + resize_factor; ++k1) {
						for (int k2 = j; k2 < j + resize_factor; ++k2) {
							s += vari.in->imagine[k1][k2].r;
						}
					}

					aritm = (int) (s / (resize_factor * resize_factor));
					
					vari.out->imagine[i / resize_factor][j / resize_factor].r = aritm;
					vari.out->imagine[i / resize_factor][j / resize_factor].g = 0;
					vari.out->imagine[i / resize_factor][j / resize_factor].b = 0;
				}	
			} else if (i + (resize_factor - i % resize_factor) - 1 < end) {
				i += resize_factor - i % resize_factor - 1;
			}
		}
	} else if (resize_factor == 3 && vari.in->tip == 5) {

		for(int i = start; i < end; i += 1) {
			if (i % resize_factor == 0) {
				for (int j = 0; j < latime; j += resize_factor) {
					
						int s;
						int aritm;

						s = (int) ((int) (1 * vari.in->imagine[i][j].r) +
								   (int) (2 * vari.in->imagine[i][j + 1].r) +
							       (int) (1 * vari.in->imagine[i][j + 2].r) +
							       (int) (2 * vari.in->imagine[i + 1][j].r) +
							       (int) (4 * vari.in->imagine[i + 1][j + 1].r) +
							       (int) (2 * vari.in->imagine[i + 1][j + 2].r) +
							       (int) (1 * vari.in->imagine[i + 2][j].r) +
							       (int) (2 * vari.in->imagine[i + 2][j + 1].r) +
							       (int) (1 * vari.in->imagine[i + 2][j + 2].r));

						aritm = (int) (s / 16);
						
						vari.out->imagine[i / resize_factor][j / resize_factor].r = aritm;
						vari.out->imagine[i / resize_factor][j / resize_factor].g = 0;
						vari.out->imagine[i / resize_factor][j / resize_factor].b = 0;
						
				}
			} else if (i + (resize_factor - i % resize_factor) - 1 < end) {
				i += resize_factor - i % resize_factor - 1;
			}
		}
	}


	if (resize_factor % 2 == 0 && vari.in->tip == 6) {

		for(int i = start; i < end; i += 1) {
			if (i % resize_factor == 0) {
				for (int j = 0; j < latime; j += resize_factor) {
					
						int sr = 0, sg = 0, sb = 0;
						int aritmr, aritmg, aritmb;
						for (int k1 = i; k1 < i + resize_factor; ++k1) {
							for (int k2 = j; k2 < j + resize_factor; ++k2) {
								sr += vari.in->imagine[k1][k2].r;
								sg += vari.in->imagine[k1][k2].g;
								sb += vari.in->imagine[k1][k2].b;
							}
						}

						aritmr = (int) (sr / (resize_factor * resize_factor));
						aritmg = (int) (sg / (resize_factor * resize_factor));
						aritmb = (int) (sb / (resize_factor * resize_factor));
						
						vari.out->imagine[i / resize_factor][j / resize_factor].r = aritmr;
						vari.out->imagine[i / resize_factor][j / resize_factor].g = aritmg;
						vari.out->imagine[i / resize_factor][j / resize_factor].b = aritmb;
					
				}
			} else if (i + (resize_factor - i % resize_factor) - 1 < end) {
				i += resize_factor - i % resize_factor - 1;
			}
		}
	} else if (resize_factor == 3 && vari.in->tip == 6) {

		for(int i = start; i < end; i += 1) {
			if (i % resize_factor == 0) {
				for (int j = 0; j < latime; j += resize_factor) {
					
						int sr, sg, sb;
						int aritmr, aritmg, aritmb;
						
						sr = (int) ((int) (1 * vari.in->imagine[i][j].r) +
								   (int) (2 * vari.in->imagine[i][j + 1].r) +
							       (int) (1 * vari.in->imagine[i][j + 2].r) +
							       (int) (2 * vari.in->imagine[i + 1][j].r) +
							       (int) (4 * vari.in->imagine[i + 1][j + 1].r) +
							       (int) (2 * vari.in->imagine[i + 1][j + 2].r) +
							       (int) (1 * vari.in->imagine[i + 2][j].r) +
							       (int) (2 * vari.in->imagine[i + 2][j + 1].r) +
							       (int) (1 * vari.in->imagine[i + 2][j + 2].r));

						sg = (int) ((int) (1 * vari.in->imagine[i][j].g) +
								   (int) (2 * vari.in->imagine[i][j + 1].g) +
							       (int) (1 * vari.in->imagine[i][j + 2].g) +
							       (int) (2 * vari.in->imagine[i + 1][j].g) +
							       (int) (4 * vari.in->imagine[i + 1][j + 1].g) +
							       (int) (2 * vari.in->imagine[i + 1][j + 2].g) +
							       (int) (1 * vari.in->imagine[i + 2][j].g) +
							       (int) (2 * vari.in->imagine[i + 2][j + 1].g) +
							       (int) (1 * vari.in->imagine[i + 2][j + 2].g));

						sb = (int) ((int) (1 * vari.in->imagine[i][j].b) +
								   (int) (2 * vari.in->imagine[i][j + 1].b) +
							       (int) (1 * vari.in->imagine[i][j + 2].b) +
							       (int) (2 * vari.in->imagine[i + 1][j].b) +
							       (int) (4 * vari.in->imagine[i + 1][j + 1].b) +
							       (int) (2 * vari.in->imagine[i + 1][j + 2].b) +
							       (int) (1 * vari.in->imagine[i + 2][j].b) +
							       (int) (2 * vari.in->imagine[i + 2][j + 1].b) +
							       (int) (1 * vari.in->imagine[i + 2][j + 2].b));

						aritmr = (int) (sr / 16);
						aritmg = (int) (sg / 16);
						aritmb = (int) (sb / 16);
						
						vari.out->imagine[i / resize_factor][j / resize_factor].r = aritmr;
						vari.out->imagine[i / resize_factor][j / resize_factor].g = aritmg;
						vari.out->imagine[i / resize_factor][j / resize_factor].b = aritmb;
					
				}
			} else if (i + (resize_factor - i % resize_factor) - 1 < end) {
				i += resize_factor - i % resize_factor - 1;
			}
		}
	}
	
	return NULL;
}

void resize(image *in, image * out) { 
	
	pthread_t tid[num_threads];
	struct_paral thread_id[num_threads];

	out->tip = in->tip;
	out->latime = in->latime / resize_factor;
	out->inaltime = in->inaltime / resize_factor;
	out->maxim = in->maxim;

	out->imagine = malloc(sizeof(rgb *) * in->inaltime / resize_factor);
	for (int i = 0; i < in->inaltime / resize_factor; ++i) {
		out->imagine[i] = malloc(sizeof(rgb) * in->latime / resize_factor);
	}

	for(int i = 0; i < num_threads; i++) {
		thread_id[i].id = i;
		thread_id[i].in = in;
		thread_id[i].out = out;
	}
		
	 for(int i = 0; i < num_threads; i++) {
	 	pthread_create(&(tid[i]), NULL, threadFunction, &(thread_id[i]));
	}

	for(int i = 0; i < num_threads; i++) {
		pthread_join(tid[i], NULL);
	}
}