#ifndef HOMEWORK_H
#define HOMEWORK_H

typedef struct {
	unsigned char r;
	unsigned char g;
	unsigned char b;
}rgb;

typedef struct {
	int tip;
	int latime;
	int inaltime;
	int maxim;
	rgb** imagine;
}image;

typedef struct {
	image *in;
	image *out;
	int id;
}struct_paral;

void readInput(const char * fileName, image *img);

void writeData(const char * fileName, image *img);

void resize(image *in, image * out);

#endif /* HOMEWORK_H */