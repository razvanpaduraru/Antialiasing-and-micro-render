#include "homework1.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <math.h>

int num_threads;
int resolution;

void initialize(image *im) {
	im->imagine = malloc(resolution * sizeof(unsigned char *));
	for (int i = 0; i < resolution; ++i) {
		im->imagine[i] = malloc(resolution * sizeof(unsigned char));
		memset(im->imagine[i], 255, resolution * sizeof(unsigned char));
	}
}

void* threadFunction(void *var) { 
	thrStr s = *(thrStr*) var;

	int start = s.id * (resolution / num_threads);
	int end = start + (resolution / num_threads);

	if(s.id == num_threads - 1) {
		end = resolution;
	}

	for (int i = resolution - 1; i >= 0; --i) {
		for (int j = start; j < end; ++j) {
			if (((abs(-1 * (j + 0.5) * 100 / resolution + 2 * (i + 0.5) * 100 / resolution)) / sqrt(5)) <= 3) {
				memset(&s.im->imagine[resolution - i - 1][j], 0, sizeof(unsigned char));
			}
		}
	}

	return NULL;	
}

void render(image *im) {
	pthread_t tid[num_threads];
	thrStr thread_id[num_threads];

	for(int i = 0; i < num_threads; i++) {
		thread_id[i].id = i;
		thread_id[i].im = im;
	}
		
	for(int i = 0; i < num_threads; i++) {
	 	pthread_create(&(tid[i]), NULL, threadFunction, &(thread_id[i]));
	}

	for(int i = 0; i < num_threads; i++) {
		pthread_join(tid[i], NULL);
	}
}

void writeData(const char * fileName, image *img) {
	FILE* file = fopen(fileName, "w");

	fprintf(file, "P5\n%d %d\n255\n", resolution, resolution);

	for (int i = 0; i < resolution; ++i) {
		fwrite(img->imagine[i], 1, resolution * sizeof(unsigned char), file);
	}
}

